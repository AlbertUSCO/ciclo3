<template>
  <h1>Mi Componente</h1>
  <p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro unde
    similique est voluptatibus quam culpa incidunt dicta eos, quibusdam dolore
    esse delectus quis voluptatem magni id temporibus nulla odio cum.
  </p>
</template>

<script>
export default {
};
</script>

<style>
</style>