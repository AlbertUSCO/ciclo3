module.exports = {
    db: "mongodb+srv://ciclo3:ciclo3@cluster0.a6x9d.mongodb.net/utp_grupo32?retryWrites=true&w=majority"
    //db: "mongodb://localhost:27017/utp_grupo32"
}