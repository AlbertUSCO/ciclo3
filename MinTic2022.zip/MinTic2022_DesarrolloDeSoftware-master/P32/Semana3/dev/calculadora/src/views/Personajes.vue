<template>
  <personajes />
</template>

<script>
import Personajes from '../components/Personajes.vue'

export default {
  components: { 
      Personajes 
    },
}
</script>

<style>

</style>