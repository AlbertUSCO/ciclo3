<template>
  <v-container>
    <p class="text-center">
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim nihil illum
    hic commodi omnis incidunt quod animi necessitatibus ipsum voluptas
    corporis, dolores rem et tenetur ea eaque quas! Dolor, sint!
    <br />
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat qui magni
    quod dolor debitis tempora quas cum quibusdam perspiciatis aspernatur, quae
    numquam accusantium quo cupiditate, ut eius ipsam voluptatibus laboriosam?
    </p>
  </v-container>
</template>

<script>
export default {};
</script>

<style>
</style>