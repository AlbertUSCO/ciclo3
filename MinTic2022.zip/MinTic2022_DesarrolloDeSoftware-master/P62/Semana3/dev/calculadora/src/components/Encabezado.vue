<template>
  <v-container>
    <v-row justify="center">
      <v-col>
        <p>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Est possimus
          cumque temporibus laudantium perspiciatis illo facilis blanditiis
          iste? Aliquid ipsam odio voluptate voluptatum qui alias laborum quae
          harum repellat dolores? 
          <br /> 
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {};
</script>

<style>
</style>